/* Program: skeleton_code3D.cpp
*
* This skeleton can be used as a starting
* point for most 3D applications.
*
*/

#ifdef __APPLE__
#include <unistd.h>
#include <GLUT/glut.h>
#else
#include <windows.h>
#include <GL/freeglut.h>
#endif

#include <math.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

#define WinW 500
#define WinH 500

float x_rotate = 0;
float rotation_factor = 7;

void head() {
	glPushMatrix();

	glScalef(2, 3, 1);
	glutSolidSphere(0.10, 18, 8);

	glPopMatrix();
}

void torso() {
	glPushMatrix();

	glRotatef(90, 1, 0, 0);
	glutSolidCylinder(0.20, 1, 18, 8);

	glPopMatrix();
}

void left_upper_arm() {
	glPushMatrix();
	
	glRotatef(-90, 1, 0, 0);
	glutSolidCylinder(0.30, 0.20, 18, 8);

	glPopMatrix();
}

void left_lower_arm() {
	glPushMatrix();

	glRotatef(-90, 1, 0, 0);
	glutSolidCylinder(0.20, 0.20, 18, 8);

	glPopMatrix();
}

void right_upper_arm() {
	glPushMatrix();
	
	glRotatef(90, 1, 0, 0);
	glutSolidCylinder(0.30, 0.20, 18, 8);

	glPopMatrix();
}

void right_lower_arm() {
	glPushMatrix();
	
	glRotatef(90, 1, 0, 0);
	glutSolidCylinder(0.20, 0.20, 18, 8);

	glPopMatrix();
}

void left_upper_leg() {
	glPushMatrix();
	
	glRotatef(90, 1, 0, 0);
	glutSolidCylinder(0.10, 0.60, 18, 8);

	glPopMatrix();
}

void left_lower_leg() {
	glPushMatrix();
	
	glRotatef(90, 1, 0, 0);
	glutSolidCylinder(0.10, 0.40, 18, 8);

	glPopMatrix();
}

void right_upper_leg() {
	glPushMatrix();
	
	glRotatef(90, 1, 0, 0);
	glutSolidCylinder(0.10, 0.60, 18, 8);

	glPopMatrix();
}

void right_lower_leg() {
	glPushMatrix();
	
	glRotatef(90, 1, 0, 0);
	glutSolidCylinder(0.10, 0.40, 18, 8);

	glPopMatrix();
}

void increase_rotation() {
	if (x_rotate >= 60) {
		rotation_factor = -7;
	}
	else if(x_rotate <= -60) {
		rotation_factor = 7;
	}

	x_rotate += rotation_factor;

	glutPostRedisplay();
}

/*
*  This function is called whenever the display needs to redrawn.
*  First call when program starts.
*/
void Display(void)
{
	/* draw to the back buffer */
	glDrawBuffer(GL_BACK);

	/* clear the display */
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);

	/* insert graphics code here that draws the scene */
	cout << "Display event occurred" << endl;

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_LIGHT0);

	glLoadIdentity();
	// Draw Head		--------------------
	glTranslatef(0, 1.2, 0);
	head();

	// Draw Torso		--------------------	
	glLoadIdentity();
	glTranslatef(0, 0.75, 0);
	torso();

	// Draw Left Arm	--------------------

	// Draw Left Upper Arm
	glLoadIdentity();
	glTranslatef(-0.65, 0.35, 0);
	left_upper_arm();

	// Draw Left Lower Arm
	glTranslatef(-0.7, 0, 0);
	left_lower_arm();

	// Draw Right Arm	--------------------

	// Draw Right Upper Arm
	glLoadIdentity();
	glTranslatef(0.65, 0.50, 0);
	right_upper_arm();

	// Draw Right Lower Arm
	glTranslatef(0.7, 0, 0);
	right_lower_arm();

	// Draw Left Leg	--------------------

	// Draw Left Upper Leg
	glLoadIdentity();
	glTranslatef(-0.15, -0.75, 0);
	left_upper_leg();

	// Draw Left Lower Leg
	glTranslatef(0, -0.90, 0);
	left_lower_leg();

	// Draw Right Leg	--------------------

	// Draw Right Upper Leg
	glLoadIdentity();
	glTranslatef(0.15, -1.05, 0);
	right_upper_leg();

	// Draw Right Lower Leg
	glTranslatef(0, -0.5, 0);
	right_lower_leg();


	/* before returning, flush the graphics buffer
	* so all graphics appear in the window */
	glFlush();
	glutSwapBuffers();
}

/*
*  reshape event occurs when the user resizes
*  the window and when the window first pops up;
*  unregistered callback.
*/
void Reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	if (w <= h)
		glOrtho(-2.0, 2.0, -2.0 * (GLfloat)h / (GLfloat)w,
		2.0 * (GLfloat)h / (GLfloat)w, -10.0, 10.0);
	else
		glOrtho(-2.0 * (GLfloat)w / (GLfloat)h,
		2.0 * (GLfloat)w / (GLfloat)h, -2.0, 2.0, -10.0, 10.0);
	glMatrixMode(GL_MODELVIEW);
}

/*
*  Mouse event occurs when a mouse button is pressed
*  OR released. The button parameter may be
*  GLUT_LEFT_BUTTON (0), GLUT_RIGHT_BOTTON (2), or
*  GLUT_MIDDLE_BUTTON (1). The state parameter is
*  GLUT_DOWN (0) if the mouse button was pressed, and
*  GLUT_UP (1) if the mouse button was released.
*  (x,y) is the location of the mouse in the screen
*  window coordinate system.
*/
void Mouse(int button, int state, int x, int y)
{
	cout << "The mouse event occurred." << endl;
	cout << "button: " << button << endl;
	cout << "state:  " << state << endl;
	cout << "x:      " << x << endl;
	cout << "y:      " << y << endl;
}

/*
*  A keyboard event occurs when the user presses a key.
*/
void Keyboard(unsigned char key, int x, int y)
{
	cout << "Keyboard event occurred\n";
	cout << "key:    " << key << endl;
	cout << "x:      " << x << endl;
	cout << "y:      " << y << endl;

	switch (key)
	{
	case 'q':	exit(0);
	case 'a':	increase_rotation();
	}
}


/*
* An idle event is generated when no other
* event occurs.
*/
void Idle(void)
{
	cout << "Idle event occurred\n";
}

/*
* Timer callback function.
*/
void Timer(int value)
{
	/* Set the next timer event to occur.
	* The arguments 100, Timer, and 1 are
	* the number of milliseconds until the
	* event is triggered, the name of the
	* function to invoke at that time, and
	* the value to be passed to that function.
	*/
	//glutTimerFunc(100, Timer, 1);
}

/*
* Set window attributes
*/
void myInit()
{
	/* set color used when clearing the window to black */
	glClearColor(0.0, 0.0, 0.0, 0.0);

	/* set drawing color to white */
	glColor3f(1.0, 1.0, 1.0);

	/* set up orthographic projection */
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-2, 2, -2, 2, -10.0, 10.0);

	/* Enable hidden--surface--removal */
	glEnable(GL_DEPTH_TEST);
}

void main(int argc, char ** argv)
{
	/* initialize graphics window */
	glutInit(&argc, argv);

	/* need both double buffering and z buffer */
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	/* set size of graphics window and position
	* of upper left corner on display */
	glutInitWindowSize(WinW, WinH);
	glutInitWindowPosition(0, 0);

	/* create the window */
	glutCreateWindow("Name of Project Here");

	/* register callback functions */
	glutDisplayFunc(Display);
	glutKeyboardFunc(Keyboard);
	glutMouseFunc(Mouse);
	glutReshapeFunc(Reshape);
	/* glutTimerFunc( 100, Timer, 1 );*/

	//glutIdleFunc(Idle);
	/* set window attributes */
	myInit();

	/* start event processing */
	glutMainLoop();
}